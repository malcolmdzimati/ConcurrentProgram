// Name:
// Student Number:

public class Queue extends Thread
{
	Store store;

	public Queue(Store s){
		store = s;
	}

	@Override
	public void run()
	{

	}
}
