import java.util.concurrent.locks.Lock;

// Name:
// Student Number:

public class Store
{
	Lock l;

	public void enterStore(){

	}
}
